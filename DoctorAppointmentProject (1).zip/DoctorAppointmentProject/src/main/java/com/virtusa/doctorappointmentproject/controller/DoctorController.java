package com.virtusa.doctorappointmentproject.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.virtusa.doctorappointmentproject.db.DbConnection;
import com.virtusa.doctorappointmentproject.model.AppointmentMain;
import com.virtusa.doctorappointmentproject.serviceimplementation.DoctorServiceImplementation;

public class DoctorController {
	protected  static final String URL="jdbc:mysql://127.0.0.1:3306/doctor_appointment";
	protected static final String PASS="shanu.shanu";
	protected static final String MR="--------------------------------------------------------------------";
	protected static final String DN="d_name";
	DoctorServiceImplementation doctorserviceimplementation=new DoctorServiceImplementation();
	protected  boolean fl=true;
	Statement stmt;
	Connection con;
	static Logger log=LogManager.getLogger(DoctorController.class.getName());
	public void doctor() throws Exception {
		try (Scanner sc = new Scanner(System.in)) {
			int choice=0;
			
			boolean flag=true;
			while(flag)
			{
				
				log.info(MR);
				log.info("\t\t  _________________________");
				log.info("\t\t |                         |");
				log.info("\t\t | Welcome to Doctor Page! |");
				log.info("\t\t |_________________________|");
				log.info(MR);
				

				log.info("1. Login \t 2.Registration \t 3.Home Page");
				choice=sc.nextInt();

				switch(choice)
				{
				case 1:
					
					try{DbConnection dbmsconnect=new DbConnection(URL,"root",PASS);
					con=dbmsconnect.getConnection();
					String sql="select d_doctormobil from doctor_details";
					stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery(sql);
					if(rs.next())
					
					{
						doctorserviceimplementation.doctorLogin();
						flag=false;

					}
					else
					{
						log.info("Register first...!");
						flag=false;
						Thread.sleep(500);
						break;
					}}catch(InterruptedException e) {
						Thread.currentThread().interrupt();
					}
					finally {
						try {
							stmt.close();
							con.close();
						}catch(NullPointerException e) {
							log.info(e);
						}
					}

					break;
				case 2:
					doctorserviceimplementation.doctorRegistration();
					flag= false;
					break;
				case 3:
					
					AppointmentMain.main(null);
					break;

				default:
					log.info("Entered Wrong choice..");
					
				}
			}
		}	
	}

}
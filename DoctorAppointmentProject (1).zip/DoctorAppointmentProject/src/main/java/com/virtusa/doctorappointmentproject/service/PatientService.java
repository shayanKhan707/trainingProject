package com.virtusa.doctorappointmentproject.service;

import java.sql.SQLException;

public interface PatientService {
	public void patientLogin();
	public void patientRegistration() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException;
	
}
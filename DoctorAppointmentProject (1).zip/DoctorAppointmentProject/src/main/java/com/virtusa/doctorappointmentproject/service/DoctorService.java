package com.virtusa.doctorappointmentproject.service;

public interface DoctorService {
	 public void doctorLogin();
	 public void doctorRegistration();
	 public void home();
}
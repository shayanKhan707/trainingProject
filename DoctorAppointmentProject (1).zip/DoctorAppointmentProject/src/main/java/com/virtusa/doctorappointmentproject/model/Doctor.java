package com.virtusa.doctorappointmentproject.model;

public class Doctor {
	private String doctorname;
	private String doctorqualification;
	private String doctorgender;
	private int  doctorage;
	private String doctormobile;
	private String doctorcity;
	public String getDoctorname() {
		return doctorname;
	}
	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}
	public String getDoctorqualification() {
		return doctorqualification;
	}
	public void setDoctorqualification(String doctorqualification) {
		this.doctorqualification = doctorqualification;
	}
	public String getDoctorgender() {
		return doctorgender;
	}
	public void setDoctorgender(String doctorgender) {
		this.doctorgender = doctorgender;
	}
	
	
	public int getDoctorage() {
		return doctorage;
	}
	public void setDoctorage(int doctorage) {
		this.doctorage = doctorage;
	}
	public String getDoctormobile() {
		return doctormobile;
	}
	public void setDoctormobile(String doctormobile) {
		this.doctormobile = doctormobile;
	}
	public String getDoctorcity() {
		return doctorcity;
	}
	public void setDoctorcity(String doctorcity) {
		this.doctorcity = doctorcity;
	}
	public Doctor(String doctorname, String doctorqualification, String doctorgender, 
			int doctorage, String doctormobile, String doctorcity) {
		super();
		this.doctorname = doctorname;
		this.doctorqualification = doctorqualification;
		this.doctorgender = doctorgender;
		
		this.doctorage = doctorage;
		this.doctormobile = doctormobile;
		this.doctorcity = doctorcity;
	}
	public Doctor() {
		super();
		
	}
	@Override
	public String toString() {
		return "doctorname =" + doctorname +"\n"+ "doctorqualification =" +"\n" +doctorqualification +"\n"+ "doctorgender ="
				+ doctorgender +"\n"+ "doctorage =" + doctorage+"\n" + "doctormobile ="
				+ doctormobile +"\n" + "doctorcity =" + doctorcity + "\n\n\n";
	}
	
	

}
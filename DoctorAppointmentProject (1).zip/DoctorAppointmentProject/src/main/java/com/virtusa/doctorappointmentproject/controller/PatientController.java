package com.virtusa.doctorappointmentproject.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.virtusa.doctorappointmentproject.db.DbConnection;
import com.virtusa.doctorappointmentproject.model.AppointmentMain;
import com.virtusa.doctorappointmentproject.serviceimplementation.PatientServiceImplementation;



public class PatientController {
	static Logger log=LogManager.getLogger(PatientController.class.getName());
	PatientServiceImplementation patientserviceimplementation=new PatientServiceImplementation();
	
	private static final String MS="\t\t _________________________";
	
	
	
	
	private static final String ST="jdbc:mysql://127.0.0.1:3306/doctor_appointment";
	private static final String SR="shanu.shanu";
	@SuppressWarnings("resource")
	public void patient() throws Exception {
		
		boolean flag=true;
		while(flag)
		{
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			
			log.info(MS);
			log.info("\t\t | Welcome to Patient Page!|");
			log.info(MS);
			log.info(" ");
			log.info("1.Login \t 2.Registration \t 3.Home Page\n");
			int ch=new Scanner(System.in).nextInt();
			switch(ch)
			{
				case 1:
					DbConnection dbmsconnect=new DbConnection(ST,"root",SR);
					Connection con=dbmsconnect.getConnection();
					String sql="select patientName from patient_details";
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery(sql);
					if(!(rs.next()))
					{
						log.info("First register yourself then login..!");
						Thread.sleep(500);
						break;
					}
					else
					{
						patientserviceimplementation.patientLogin();
						flag=false;
						
					}
					
					break;
				case 2:
					patientserviceimplementation.patientRegistration();
					flag=false;
					break;
				case 3:
					AppointmentMain.main(null);
					break;
				

				default:
					log.info("\nYou entered wrong choice. enter your choice again....!!!");
				
					Thread.sleep(1000);
					break;
			}
		}

}
}
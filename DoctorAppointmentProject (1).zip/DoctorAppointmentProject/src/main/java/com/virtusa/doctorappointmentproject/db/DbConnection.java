package com.virtusa.doctorappointmentproject.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DbConnection {
	String url;
	String username;
	String password;
	public DbConnection(String url,String username,String password) {
		this.url=url;
		this.username=username;
		this.password=password;
	}
	@SuppressWarnings("deprecation")
	public Connection getConnection() throws IllegalAccessException, ClassNotFoundException, SQLException, InstantiationException {
		Connection con=null;
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		con=DriverManager.getConnection(url,username,password);
		return con;
		
		
		
	}
	public void closeConnection(Connection con,Statement stmt) throws SQLException {
		stmt.close();
		con.close();
		
	}

}
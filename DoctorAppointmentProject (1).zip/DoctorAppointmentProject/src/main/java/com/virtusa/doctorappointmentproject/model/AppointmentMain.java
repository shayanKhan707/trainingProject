package com.virtusa.doctorappointmentproject.model;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.virtusa.doctorappointmentproject.controller.AdminController;
import com.virtusa.doctorappointmentproject.controller.DoctorController;
import com.virtusa.doctorappointmentproject.controller.PatientController;



public class AppointmentMain {
	static Logger log=LogManager.getLogger(AppointmentMain.class.getName());
	static boolean flag=false;
	public static void main(String[] args) throws Exception {
		DoctorController doctorcontroller=new DoctorController();
		PatientController patientcontroller=new PatientController();
		AdminController admincontroller=new AdminController();
		Exit exit=new Exit();
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		if(!flag)
		{
		log.info("---------------------------------------------------------------------");
		log.info("\t\t | Welcome to Doctor AppointmentBooking |");
		log.info("----------------------------------------------------------------------\n\n");
		log.info("1. Doctor \t 2. Patient \t 3. Admin \t 4. Exit");
		int choice=sc.nextInt();
		switch(choice) {
		case 1:
			doctorcontroller.doctor();
			break;
			case 2:
			patientcontroller.patient();								
			break;
			case 3:
			
			admincontroller.admin();
			break;
			case 4:
				exit.exit();
				System.exit(0);
				break;
			default:
			System.exit(0);


		}
		
		
		
		}
		
		
	
		
	}

}
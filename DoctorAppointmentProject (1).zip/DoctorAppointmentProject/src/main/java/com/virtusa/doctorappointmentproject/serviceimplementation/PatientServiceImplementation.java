package com.virtusa.doctorappointmentproject.serviceimplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.virtusa.doctorappointmentproject.db.DbConnection;
import com.virtusa.doctorappointmentproject.model.AppointmentMain;

import com.virtusa.doctorappointmentproject.service.PatientService;

public class PatientServiceImplementation implements PatientService{
	static Logger log=LogManager.getLogger(PatientServiceImplementation.class.getName());
	private static final String MS="\t\t _________________________";
	private static final String DQ="d_qualification";
	protected  static final String URL="jdbc:mysql://127.0.0.1:3306/doctor_appointment";
	protected static final String PASS="shanu.shanu";
	protected static final String MR="--------------------------------------------------------------------";
	protected static final String DN="d_name";
	private String dmbile;
	private String docname;
	private String slotss;
	Connection con;
	Statement opi;
	PreparedStatement pi;
	@SuppressWarnings("resource")
	@Override
	public void patientLogin() {
		try (Scanner sc = new Scanner(System.in)) {
			String mobileNumber;
			
			log.info(MS);
			log.info("\t\t |                       |");
			log.info("\t\t |\t Login \t\t|");
			log.info("\t\t |_______________________|");

			log.info("Enter your Username(mobilenumber)");
			mobileNumber=sc.nextLine();
			log.info("Enter your Password");
			String password=sc.next();
			boolean flag1=false;
			try {
			DbConnection dbmsconnect=new DbConnection(URL,"root",PASS);
			con=dbmsconnect.getConnection();
			Statement si;
			String thiss = "select patientName from patient_details where patientMobileNumber=? and patientPassword=?";
			PreparedStatement dtmt=con.prepareStatement(thiss);
			dtmt.setString(1,mobileNumber);
			dtmt.setString(2, password);
			ResultSet rs=dtmt.executeQuery();
			if(rs.next()) {
				flag1=true;	
			}
			if(flag1)
			{		
				Thread.sleep(1000);
				new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
					log.info("\t\t  _________________________");
					log.info("\t\t |                         |");
					log.info("\t\t |     Book Appointment    |");
					log.info("\t\t |_________________________|");
					log.info(" Welcome  {} , to book appointment, choose your doctor..",rs.getString("patientName"));
				
					Thread.sleep(1000);

					new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
					log.info("\t\t  _________________________");
					log.info("\t\t |                         |");
					log.info("\t\t |     Book Appointment    |");
					log.info("\t\t |_________________________|");
				
				showdetails();
				log.info("Enter doctor mobile no. to book appointment : ");
				String domobile=new Scanner(System.in).nextLine();
				dmbile=domobile;
				openslot();
				Thread.sleep(3000);
				log.info("Enter Date");
				String dte=new Scanner(System.in).nextLine();
				log.info("Enter Slot :");
				String slot=new Scanner(System.in).nextLine();
				slotss=slot;
				String sop="select "+slot+" from doctor_slot where date1="+"'"+dte+"'"+"and "+"d_mobile="+"'"+domobile+"'";
				si=con.createStatement();
				ResultSet rpo=si.executeQuery(sop);
				if(rpo.next()) {
			
					log.info("Enter Your name :");
					String una=new Scanner(System.in).nextLine();
					log.info("Enter Your age :");
					int uage=new Scanner(System.in).nextInt();
					String agee=String.valueOf(uage);
					log.info("Enter  Your gender(M/F) :");
					String gn=new Scanner(System.in).nextLine();
					
					String time=rpo.getString(1);
					
				  

					
					String popd="insert into patient_booking_details(patientNameBooking,patientAgeBooking,patientGenderBooking,d_name,patientMobileNumber,datee,timee) values(?,?,?,?,?,?,?)";
					if(genderv(gn) &&  checkage(uage) && setime(time)) 
					{
						
					
					PreparedStatement pe=con.prepareStatement(popd);
					pe.setString(1, una);
					pe.setString(2, agee);
					pe.setString(3, gn);
					pe.setString(4, docname);
					pe.setString(5, mobileNumber);
					pe.setString(6,dte);
					pe.setString(7,time);
					int i=pe.executeUpdate();
					if(i>0){
						log.info("Booking Successful...");
						deleteslots();

						
					}
					else {
						log.info("Enter Correct Input !!");
					}
					AppointmentMain.main(null);
			}else {
					log.info("Invalid Format...!!");
				}
				
				}
				else
				{
					log.info("Invalid Credentials ...!!!");
				}
				
				
			
}
			else {
				log.info("Invalid Credentials !!");
				Thread.sleep(900); 
				AppointmentMain.main(null);
				
				
			}
				
			}
			catch(Exception e) {
				log.info(e);
				log.info("Appointment not Available");
				Thread.currentThread().interrupt();
				try {
					AppointmentMain.main(null);
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}
				
			}
			}
		}
			
	
	@SuppressWarnings("resource")
	private void showdetails() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		log.info("Enter Doctor type : ");
		String no=new Scanner(System.in).nextLine();
		if(!(no.equals("Orthopedecian")|| no.equals("Cardiologist")|| no.equals("MBBS")||no.equals("Gynecologist"))) {
			log.info("Invalid doctor type");
			showdetails();
		}
		else {
		
		
		PreparedStatement pry=null;
		Statement str=null;
		
		try{DbConnection dbc=new DbConnection(URL,"root",PASS);
		con=dbc.getConnection();
		str=con.createStatement();
		String lis="select d_name,d_qualification,d_doctorgender,d_doctorage,d_doctormobil,d_doctorcity from doctor_details where d_qualification=?";
		pry=con.prepareStatement(lis);
		pry.setString(1, no);
		
		ResultSet we=pry.executeQuery();
		log.info(MR);
		log.info(MR);
		
		log.info("Doctor Name\t\t"+"Doctor Qualification\t\t"+"Doctor Gender\t\t"+"Doctor Age\t\t"+"Doctor Mobile no.\t\t"+"Doctor City\t\t");
		while(we.next()) {
			if(we.getString(DQ).length()<10 && we.getString(DN).length()<15) {
				log.info("{} \t\t\t {} \t\t {} \t\t\t {} \t\t\t {} \t\t\t {}",we.getString(DN),we.getString(DQ),we.getString("d_doctorgender"),we.getString("d_doctorage"),we.getString("d_doctormobil"),we.getString("d_doctorcity"));
				
				
			}
			
			else {
				log.info("{} \t\t {} \t\t {} \t\t\t {} \t\t\t {} \t\t\t {}",we.getString(DN),we.getString(DQ),we.getString("d_doctorgender"),we.getString("d_doctorage"),we.getString("d_doctormobil"),we.getString("d_doctorcity"));
				
				
			}
		}
		}catch(Exception e) {
			log.info(e);
		}
		finally {
			try {
			str.close();
			con.close();
			}catch(NullPointerException e) {
				log.info(e);
			}
		}
		log.info(MR);
		log.info(MR);
		}
		
		
	}

	@SuppressWarnings("resource")
	@Override
	public void patientRegistration() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		
		log.info("\n");
		log.info(MS);
		log.info("\t\t  Welcome to Patient Registration Page !");
		log.info(MS);
		log.info("\n");
		log.info("Please enter your name");
		String mop=new Scanner(System.in).nextLine();
		log.info("enter your age: ");
		int age=new Scanner(System.in).nextInt();
		log.info("Please enter your gender(M/F) :");
		String gd=new Scanner(System.in).nextLine();
		log.info("Please enter your Mobile number (**10 digits**)");
		String mobilenu=new Scanner(System.in).nextLine();
		DbConnection dbconnect=new DbConnection(URL,"root",PASS);
		con=dbconnect.getConnection();
		String ppp="select patientName from patient_details where patientMobileNumber=?";
		PreparedStatement put=con.prepareStatement(ppp);
		put.setString(1, mobilenu);
		ResultSet rt=put.executeQuery();
		if(rt.next()) {
			log.info("Patient already registered ");
		}
		else {
			log.info("Set password (8-12 characters ,at least(one small,capital,digit,specialcharacter[#$%@])) ");
			String pass=new Scanner(System.in).nextLine();
			log.info("Confirm password : ");
			String pass1=new Scanner(System.in).nextLine();
			if(isvalid(mobilenu) && passvalid(pass) && genderv(gd)) {
			if(pass.equals(pass1)) {
				String popo="insert into patient_details(patientName,patientAge,patientGender,patientPassword,patientConfirmedPassword,patientMobileNumber) values(?,?,?,?,?,?);";
				PreparedStatement ut=con.prepareStatement(popo);
				ut.setString(1, mop);
				ut.setInt(2,age );
				ut.setString(3, gd);
				ut.setString(4, pass);
				ut.setString(5, pass1);
				ut.setString(6, mobilenu);
				int i=ut.executeUpdate();
				if(i>0) {
					log.info("Registration Successful");
				}
				else {
					log.info("Please Enter correct details");
				}
				
			}
			else {
				log.info("Password mismatch !!");
			}
			try {
				AppointmentMain.main(null);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			
			
			
		}else {
			log.info("Enter details as per required !!!");
			patientRegistration();
		}
			}
		
	
		
	}

	
		public void openslot() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		
		DbConnection dbconnect=new DbConnection(URL,"root",PASS);
		try {
		con=dbconnect.getConnection();
		String qery="select * from doctor_slot where d_mobile=?";
		pi=con.prepareStatement(qery);
		pi.setString(1, dmbile);
		ResultSet rs=pi.executeQuery();
		log.info(MR);
		log.info(MR);
		Thread.sleep(1000);
		log.info(" Availability Date \t\t"+"Slot1\t\t"+"Slot2\t\t"+"Slot3\t\t"+"Slot4\t\t"+"Slot5\t\t");
		Thread.sleep(1000);
		while(rs.next()) {
			docname=rs.getString(DN);
			log.info("{} \t\t\t {} \t {} \t {}\t {}\t {}",rs.getString("date1"),rs.getString("Slot1"),rs.getString("Slot2"),rs.getString("Slot3"),rs.getString("Slot4"),rs.getString("Slot5"));
		
		}
		
		
		
	}catch(InterruptedException e) {
		Thread.currentThread().interrupt();
		log.info(e);
	}
		finally {
			pi.close();
		}
		}
	private void deleteslots() throws SQLException{
		
		DbConnection dbconnect=new DbConnection(URL,"root",PASS);
		try {
			con=dbconnect.getConnection();
			opi=con.createStatement(); 
			 String dlt="Update doctor_slot SET "+slotss+"='BOOKED'"+"where d_mobile="+"'"+dmbile+"'";
			         
			int i=opi.executeUpdate(dlt);
			if(i>0) {
				log.info("Success");
			}
		}catch(Exception e) {
			log.info(e);
		}
		finally {
			con.close();
		}
		
		
	}
	

			
		
	
	public static boolean isvalid(String po) {
		Pattern p=Pattern.compile("^[7-9]\\d{9}$");
		Matcher m=p.matcher(po);
		return m.matches();
	}
	public static boolean setime(String opl) {
		return !(opl.equals("BOOKED"));
	}
	public static boolean passvalid(String pass) {
		Pattern p=Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@%#$]).{8,12})");
		Matcher m=p.matcher(pass);
		return m.matches();
	}
	public static boolean genderv(String v) {
		return (v.equals("M") || v.equals("F") || v.equals("f") || v.equals("m"));
	}
	public static boolean slottime(String slot) {
		return slot.length()==7||slot.length()==8;
	}
	public static boolean checkage(int agecheck) {
		
			return  agecheck<=80;
		
	}

}
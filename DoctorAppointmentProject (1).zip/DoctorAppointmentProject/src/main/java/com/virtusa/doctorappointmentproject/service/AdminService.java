package com.virtusa.doctorappointmentproject.service;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.doctorappointmentproject.model.Doctor;

public interface AdminService {
	public List<Doctor> doctorList() throws SQLException;
	public void registeredPatientList() throws SQLException;	
	public void patientAppointmentList() throws SQLException;

}
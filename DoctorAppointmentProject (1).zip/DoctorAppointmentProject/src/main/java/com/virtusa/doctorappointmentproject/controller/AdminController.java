package com.virtusa.doctorappointmentproject.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.virtusa.doctorappointmentproject.db.DbConnection;
import com.virtusa.doctorappointmentproject.model.AppointmentMain;
import com.virtusa.doctorappointmentproject.serviceimplementation.AdminServiceImplementation;



public class AdminController {
	static boolean flag=false;
	private static final String ST="jdbc:mysql://127.0.0.1:3306/doctor_appointment";
	private static final String SR="shanu.shanu";
	private static final String DN="d_name";
	
	private static final String LP="patientMobileNumber";
	private static final String MR="--------------------------------------------------------------------";
	static Logger log=LogManager.getLogger(AdminController.class.getName());
	AdminServiceImplementation adminserviceimplementation=new AdminServiceImplementation();
	Connection con;
	Statement strtr;
	PreparedStatement prt;
	@SuppressWarnings("resource")
	public void admin() throws Exception {
		try (Scanner sc = new Scanner(System.in)) {
			byte choice;
			
			log.info(MR);
			log.info(MR);
			log.info("Enter admin username : ");
			String uns=new Scanner(System.in).nextLine();
			log.info("Enter admin password : ");
			String pns=new Scanner(System.in).nextLine();
			log.info(MR);
			log.info(MR);
			
			DbConnection dbc=new DbConnection(ST,"root",SR);
			con=dbc.getConnection();
			String qw="select username from admin where username=? and pass=?";
			prt=con.prepareStatement(qw);
			prt.setString(1, uns);
			prt.setString(2,pns);
			ResultSet ro=prt.executeQuery();
			if(ro.next()) {
			

			while(!flag)
			{
				new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
				log.info("\t\t  ____________________________");
				log.info("\t\t |----------------------------|");
				log.info("\t\t |*****Welcome {}****|",ro.getString("username"));
				log.info("\t\t |____________________________|\n\n");
				log.info("1. Doctor list \t2. Registered Patients list \t3.Pateints with Appointment list \t4.Home Page  \n\nEnter Your Choice.");
				choice=sc.nextByte();
			
				switch(choice)
				{
				case 1:
					adminserviceimplementation.doctorList();
					
					break;
				case  2:
					adminserviceimplementation.registeredPatientList();
			
					break;
				case 3:
					patientBookingData();

					break;
				case 4:
					AppointmentMain.main(null);
					break;
					default:
						log.info("Invalid Choice...Something Went Wrong !!!");		
}
}
			}
			else {
				log.info("Invalid Login Credentials...");
				admin();
			}
		}
}
		
	
	private void patientBookingData() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException  {
		
		try{DbConnection dbc=new DbConnection(ST,"root",SR);
		con=dbc.getConnection();
		
		String lo="select patientNameBooking,patientAgeBooking,patientGenderBooking,patientMobileNumber,d_name,datee,timee from patient_booking_details";
		strtr=con.createStatement();
		ResultSet ws=strtr.executeQuery(lo);
		log.info(MR);
		log.info(MR);
		
		log.info("Patient Name Booking\t\t"+"Patient Age\t\t"+"Patient Gender\t\t"+"Patient Mobile no.\t\t"+"Doctor Name\t\t"+"Appointment Date\t\t"+"Time");
		while(ws.next()) {
			if(ws.getString(DN).length()<=9) {
			log.info("{} \t\t\t\t {} \t\t\t  {} \t\t  {} \t\t\t {} \t\t {} \t\t\t{}",ws.getString("patientNameBooking"),ws.getString("patientAgeBooking"),ws.getString("patientGenderBooking"),ws.getString(LP),ws.getString(DN),ws.getString("datee"),ws.getString("timee")) ;
			
			
		}
			else {
				log.info("{} \t\t\t\t {} \t\t\t  {} \t\t  {} \t\t\t {} \t {} \t\t\t{}",ws.getString("patientNameBooking"),ws.getString("patientAgeBooking"),ws.getString("patientGenderBooking"),ws.getString(LP),ws.getString(DN),ws.getString("datee"),ws.getString("timee")) ;
				
			}}
		}catch(Exception e) {
			log.info(e);
		}
		finally {
			try {
			strtr.close();
			con.close();
			}catch(NullPointerException e) {
				log.info(e);
			}
		}
		log.info(MR);
		log.info(MR);
	
	
	}
	@SuppressWarnings({ "resource", "unused" })
	private void doctordelete() throws Exception {
		Scanner sc=new Scanner(System.in);
		
		new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		log.info("\t\t----------------------------------------");
		log.info("\t\t----------------------------------------");
		log.info("Press 1 to Delete Doctor record. ");
		log.info("Press 2 to go back to Home page. ");
		byte choice=sc.nextByte();
		switch(choice) {
		case 1:
			deleteit();
			break;
		case 2:
			AppointmentMain.main(null);
			break;
		default:
			System.exit(0);
			
		
		
	}
}
	@SuppressWarnings("resource")
	private void deleteit() throws SQLException {
		log.info("Enter Doctor mobile :");
		
		String dmob=new Scanner(System.in).nextLine();
		
		try {
		DbConnection dbconnect=new DbConnection(ST,"root",SR);
		con=dbconnect.getConnection();
		String qq="delete from doctor_details where d_doctormobil=?";
		prt=con.prepareStatement(qq);
		prt.setString(1, dmob);
		int i=prt.executeUpdate();
		String qqw="delete from doctor_slot where d_mobile=?";
		prt=con.prepareStatement(qqw);
		prt.setString(1, dmob);
		int j=prt.executeUpdate();
	   
		if(i>0 && j>0) {
			log.info("Record Deleted Successfully...");
		}
		
	}catch(Exception e) {
		log.info(MR);
		log.info(e);
		log.info("Invalid Data");
		
		log.info(MR);
	}
		finally {
			try {
				prt.close();
				
				con.close();
				
			}catch(NullPointerException e ) {
				log.info("Invalid Data");
			}
		}
		
	}
	

}
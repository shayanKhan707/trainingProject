package com.virtusa.doctorappointmentproject.serviceimplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.virtusa.doctorappointmentproject.db.DbConnection;
import com.virtusa.doctorappointmentproject.model.AppointmentMain;
import com.virtusa.doctorappointmentproject.model.Doctor;
import com.virtusa.doctorappointmentproject.model.Patient;
import com.virtusa.doctorappointmentproject.service.AdminService;

public class AdminServiceImplementation implements AdminService {
	static boolean flag=false;
	private static final String ST="jdbc:mysql://127.0.0.1:3306/doctor_appointment";
	private static final String SR="shanu.shanu";
	private static final String DN="d_name";
	private static final String DQ="d_qualification";
	private static final String DG="d_doctorgender";
	private static final String DA="d_doctorage";
	private static final String DM="d_doctormobil";
	private static final String DC="d_doctorcity";
	private static final String LP="patientMobileNumber";
	private static final String MR="--------------------------------------------------------------------";
	PreparedStatement prt;
	Connection con;
	Statement str;
	static Logger log=LogManager.getLogger(AdminServiceImplementation.class.getName());
	
	@Override
	public List<Doctor> doctorList() throws SQLException {

		List<Doctor> doctorlist=new ArrayList<>();
		try{DbConnection dbc=new DbConnection(ST,"root",SR);
		con=dbc.getConnection();
		str=con.createStatement();
		String lis="select d_name,d_qualification,d_doctorgender,d_doctorage,d_doctormobil,d_doctorcity from doctor_details";
		ResultSet we=str.executeQuery(lis);
		log.info(MR);
		log.info(MR);
		
		log.info("Doctor Name\t"+"Doctor Qualification\t"+"Doctor Gender\t"+"Doctor Age\t"+"Doctor Mobile no.\t"+"Doctor City\t");
		
		while(we.next()) {
			String doctorn=we.getString(DN);
			String doctorq=we.getString(DQ);
			String doctorg=we.getString(DG);
			int doctora=we.getInt(DA);
			String doctormb=we.getString(DM);
			String doctorcity=we.getString(DC);
			Doctor d1=new Doctor(doctorn,doctorq,doctorg,doctora,doctormb,doctorcity);
			doctorlist.add(d1);
			
			if(we.getString(DQ).length()<6) {
			log.info("{} \t\t {} \t\t {} \t\t {} \t\t {} \t\t {}",we.getString(DN),we.getString(DQ),we.getString(DG),we.getString(DA),we.getString(DM),we.getString(DC));
			}
			else if(we.getString(DQ).length()>=6) {
				log.info("{} \t\t {} \t {} \t\t {} \t\t {} \t\t {}",we.getString(DN),we.getString(DQ),we.getString(DG),we.getString(DA),we.getString(DM),we.getString(DC));
				
				
			}
		}
		for(Doctor p:doctorlist) {
			log.info(p);
		}
		
		}catch(Exception e) {
			log.info(e);
		}
		finally {
			try {
			str.close();
			con.close();
			}catch(NullPointerException e) {
				log.info(e);
			}
		}
		log.info(MR);
		log.info(MR);
		
		try {
			doctordelete();
		} catch (Exception e) {
			
			e.printStackTrace();
		
		}
		return doctorlist;
	}
		
	

	@Override
	public void registeredPatientList() throws SQLException {
		Set<Patient> patientlist=new HashSet<>();
		try{DbConnection dbc=new DbConnection(ST,"root",SR);
		con=dbc.getConnection();
		str=con.createStatement();
		String lop="select patientName,patientAge,patientGender,patientMobileNumber from  patient_details";
		ResultSet yu=str.executeQuery(lop);
		log.info(MR);
		log.info(MR);
		
		log.info("Patient Name\t"+"Patient Age\t"+"Patient Gender\t"+"Patient Mobile no.\t");
		while(yu.next()) {
			String pname=yu.getString("patientName");
			String page=yu.getString("patientAge");
			String pgender=yu.getString("patientGender");
			String pmobile=yu.getString(LP);
			Patient p1=new Patient(pname,page,pgender,pmobile);
			patientlist.add(p1);
			
			
			log.info("{} \t\t {} \t\t {} \t\t {}",yu.getString("patientName"),yu.getString("patientAge"),yu.getString("patientGender"),yu.getString(LP));
			
		}
		for(Patient z:patientlist) {
			log.info(z);
		}
	}catch(Exception e) {
		log.info(e);
	}
	finally {
		try {
				str.close();
			
				con.close();
			}
			catch(NullPointerException e) {
				log.info(e);
			}
		}
		log.info(MR);
		log.info(MR);
	
		
	}
		
	

	@Override
	public void patientAppointmentList() throws SQLException {
		
		Statement strtr=null;
		try{DbConnection dbc=new DbConnection(ST,"root",SR);
		con=dbc.getConnection();
		
		String lo="select patientNameBooking,patientAgeBooking,patientGenderBooking,patientMobileNumber,d_name,datee,timee from patient_booking_details";
		strtr=con.createStatement();
		ResultSet ws=strtr.executeQuery(lo);
		log.info(MR);
		log.info(MR);
		
		log.info("Patient Name Booking\t\t"+"Patient Age\t\t"+"Patient Gender\t\t"+"Patient Mobile no.\t\t"+"Doctor Name\t\t"+"Appointment Date\t\t"+"Time");
		while(ws.next()) {
			if(ws.getString(DN).length()<=9) {
			log.info("{} \t\t\t\t {} \t\t\t  {} \t\t  {} \t\t\t {} \t\t {} \t\t\t{}",ws.getString("patientNameBooking"),ws.getString("patientAgeBooking"),ws.getString("patientGenderBooking"),ws.getString(LP),ws.getString(DN),ws.getString("datee"),ws.getString("timee")) ;
			
			
		}
			else {
				log.info("{} \t\t\t\t {} \t\t\t  {} \t\t  {} \t\t\t {} \t {} \t\t\t{}",ws.getString("patientNameBooking"),ws.getString("patientAgeBooking"),ws.getString("patientGenderBooking"),ws.getString(LP),ws.getString(DN),ws.getString("datee"),ws.getString("timee")) ;
				
			}}
		}catch(Exception e) {
			log.info(e);
		}
		finally {
			try {
			strtr.close();
			con.close();
			}catch(NullPointerException e) {
				log.info(e);
			}
		}
		log.info(MR);
		log.info(MR);
	
	
	}
	@SuppressWarnings("resource")
	private void doctordelete() throws Exception {
		Scanner sc=new Scanner(System.in);
		
		new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		log.info("\t\t----------------------------------------");
		log.info("\t\t----------------------------------------");
		log.info("Press 1 to Delete Doctor record. ");
		log.info("Press 2 to go back to Home page. ");
		byte choice=sc.nextByte();
		switch(choice) {
		case 1:
			deleteit();
			break;
		case 2:
			AppointmentMain.main(null);
			break;
		default:
			System.exit(0);
			
		
		
	}
}
	@SuppressWarnings("resource")
	private void deleteit() throws SQLException {
		log.info("Enter Doctor mobile :");
		
		String dmob=new Scanner(System.in).nextLine();
		
		
		try {
		DbConnection dbconnect=new DbConnection(ST,"root",SR);
		con=dbconnect.getConnection();
		String qq="delete from doctor_details where d_doctormobil=?";
		prt=con.prepareStatement(qq);
		prt.setString(1, dmob);
		int i=prt.executeUpdate();
		String qqw="delete from doctor_slot where d_mobile=?";
		prt=con.prepareStatement(qqw);
		prt.setString(1, dmob);
		int j=prt.executeUpdate();
	   
		if(i>0 && j>0) {
			log.info("Record Deleted Successfully...");
		}
		
	}catch(Exception e) {
		log.info(MR);
		log.info(e);
		log.info("Invalid Data");
		
		log.info(MR);
	}
		finally {
			try {
				prt.close();
				
				con.close();
				
			}catch(NullPointerException e ) {
				log.info("Invalid Data");
			}
		}
		
	}
	

		
	}
	
	

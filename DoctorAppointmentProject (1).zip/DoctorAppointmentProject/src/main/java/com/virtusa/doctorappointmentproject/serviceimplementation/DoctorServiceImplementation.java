package com.virtusa.doctorappointmentproject.serviceimplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import com.virtusa.doctorappointmentproject.controller.DoctorController;
import com.virtusa.doctorappointmentproject.db.DbConnection;
import com.virtusa.doctorappointmentproject.model.AppointmentMain;
import com.virtusa.doctorappointmentproject.service.DoctorService;

public class DoctorServiceImplementation  implements DoctorService{
	static Logger log=LogManager.getLogger(DoctorServiceImplementation.class.getName());
	protected  static final String URL="jdbc:mysql://127.0.0.1:3306/doctor_appointment";
	protected static final String PASS="shanu.shanu";
	protected static final String MR="--------------------------------------------------------------------";
	protected static final String DN="d_name";
	protected  boolean fl=true;
	protected String r;
	protected String pro;
	protected String test="";
	
	Connection con;
	PreparedStatement prtr;
	PreparedStatement dtmt;
	@Override
	public void doctorLogin() {
		
		try (Scanner sc = new Scanner(System.in)) {
			String mobileNumber;
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			log.info("\t--------------------------------");
			log.info("\t\t| This is doctor login page     |");
			log.info("\t\t---------------------------------");
			log.info("\t\tEnter your Username(mobilenumber)");
			mobileNumber=sc.next();
			log.info("\t\tEnter your Password");
			String password=sc.next();
			byte choice = 0;
			boolean flag=false;
			String flag11="false";
			DbConnection dbmsconnect=new DbConnection(URL,"root",PASS);
			con=dbmsconnect.getConnection();
			String thiss = "select d_name from doctor_details where d_doctormobil=? and d_doctorpass=?";
			dtmt=con.prepareStatement(thiss);
			dtmt.setString(1,mobileNumber);
			dtmt.setString(2, password);
			ResultSet rs=dtmt.executeQuery();
			if(rs.next()){
			flag=true;
			flag11="true";
			r=rs.getString(DN);
			pro=mobileNumber;
			
			}
			while(flag)
			{
			
					log.info("\t----------------------------------");
					log.info("\t\t| Welcome Doctor  {}  |",rs.getString(DN));
					log.info("\t\t----------------------------------");
					log.info("Press 1 to see your Appointments. ");
					log.info("Press 2 to enter your Availability time. ");
					log.info("Press 3 to go back to Home page. ");
					test=rs.getString(DN);
					choice=sc.nextByte();
				
					switch(choice)
					{
					case 1:
						detailspatient();
						break;
					
					case 2:
					    slotavailability();
						break;
					case 3:
						
					 AppointmentMain.main(null);
						
						break;
					
					default:
						log.info("Invalid choice :)");
						System.exit(0);
						
				}	
					
			}
			if(flag11.equals("false"))
			{
				log.info("Invalid Credentials !!");
				Thread.sleep(900); 
				
				AppointmentMain.main(null);
			}
		}catch(Exception e) {
			Thread.currentThread().interrupt();
		}
		finally {
			try {
				dtmt.close();
				con.close();
			}catch(NullPointerException e) {
				log.info(e);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}
 		
 		
 		 
	
		
	}

	@SuppressWarnings("resource")
	private void slotavailability() {
		DoctorController doctorcontroller=new DoctorController();
		
		
		log.info("\t----------------------------------");
		log.info("\t\t| Hello Doctor   {}  |",r);
		log.info("\t\t----------------------------------");
		try{DbConnection dbmsconnect=new DbConnection(URL,"root",PASS);
		con=dbmsconnect.getConnection();
			log.info("Enter the respective date(dd-mm-yyyy) :");
			String datee=new Scanner(System.in).nextLine();
			log.info("Enter Slot-1(hh:mm pm/am):");
			String tme1=new Scanner(System.in).nextLine();
			log.info("Enter Slot-2(hh:mm pm/am):");
			String tme2=new Scanner(System.in).nextLine();
			log.info("Enter Slot-3(hh:mm pm/am) :");
			String tme3=new Scanner(System.in).nextLine();
			log.info("Enter Slot-4(hh:mm pm/am):");
			String tme4=new Scanner(System.in).nextLine();
			log.info("Enter Slot-5(hh:mm pm/am):");
			String tme5=new Scanner(System.in).nextLine();
			String ryt="update doctor_slot set date1=?,Slot1=?,Slot2=?,Slot3=?,Slot4=?,Slot5=? where d_mobile=?";
			PreparedStatement insr=con.prepareStatement(ryt);
			insr.setString(1, datee);
			insr.setString(2, tme1);
			insr.setString(3, tme2);
			insr.setString(4, tme3);
			insr.setString(5, tme4);
			insr.setString(6, tme5);
			insr.setString(7, pro);
			int l=insr.executeUpdate();
			if(l>0) {
				log.info("Records has been updated Successfully..");
				AppointmentMain.main(null);
			}
			else {
				log.info("Invalid data..");
				doctorcontroller.doctor();
				
			}
			
		
		}catch(Exception e) {
			log.info(e);
			log.info("Register Again");
		}
		

		
		
	}

	private void detailspatient() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		
		try{DbConnection dbmsconnect=new DbConnection(URL,"root",PASS);
 		con=dbmsconnect.getConnection();
		String ho="select patientNameBooking,patientAgeBooking,patientGenderBooking,patientMobileNumber,datee,timee from patient_booking_details where d_name=?";
		prtr=con.prepareStatement(ho);
		prtr.setString(1,test);
		ResultSet rp=prtr.executeQuery();
		log.info(MR);
		log.info(MR);
		
		log.info("Patient Name\t\t"+"Patient Age\t\t"+"Patient Gender\t\t"+"Patient Mobile\t\t"+"Appointment Date\t\t"+"Time");
		
		while(rp.next()) {
			fl=false;
			log.info("{} \t\t {} \t\t\t {} \t\t\t {} \t\t {} \t\t\t {}",rp.getString("patientNameBooking"),rp.getString("patientAgeBooking"),rp.getString("patientGenderBooking"),rp.getString("patientMobileNumber"),rp.getString("datee"),rp.getString("timee"));
			Thread.sleep(1000);
		}
		log.info(MR);
		log.info(MR);
		
		if(fl){
			log.info("No Appointments...!");
			Thread.sleep(3000);
		}
	}catch(InterruptedException e) {
		Thread.currentThread().interrupt();
	}finally {
		try {
		prtr.close();
		con.close();
		
	}catch(NullPointerException e ) {
		log.info(e);
	}
		}

		
	}

	@SuppressWarnings("resource")
	@Override
	public void doctorRegistration() {
		
		DoctorController doctorcontroller=new DoctorController();
		
		log.info("\t ----------------------------------");
		log.info("\t\t| This is doctor registration Page |");
		log.info("\t\t ----------------------------------");
		log.info("\n");
		
		log.info("Please enter your name");
		String uname=new Scanner(System.in).nextLine();
		log.info("Enter qualification");
		String uq=new Scanner(System.in).nextLine();
		log.info("Enter gender(M/F)");
		String p=new Scanner(System.in).nextLine();
		log.info("Enter Mobile number (**10 digits**)");
		String mnum=new Scanner(System.in).nextLine();
		log.info("Enter age (**more than 20**)");
		int agg=new Scanner(System.in).nextInt();
		log.info("Enter Area and City: ");
		String ct=new Scanner(System.in).nextLine();
		log.info("Set password (8-12 characters ,at least(one small,capital,digit,specialcharacter[#$%@]))");
		String pas=new Scanner(System.in).nextLine();
		if(isvalid(mnum) && agevalid(agg) && passvalid(pas) && genderv(p) ) {
		try {
		DbConnection dbconnect=new DbConnection(URL,"root",PASS);
		 con=dbconnect.getConnection();
		String qq="insert into doctor_details(d_name,d_qualification,d_doctorgender,d_doctorpass,d_doctorage,d_doctormobil,d_doctorcity) values (?,?,?,?,?,?,?)";
		String cc="insert into doctor_slot(d_name,d_mobile) values(?,?)";
		PreparedStatement prt=con.prepareStatement(qq);
		prt.setString(1, uname);
		prt.setString(2, uq);
		prt.setString(3, p);
		prt.setString(4,pas );
		prt.setInt(5, agg);
		prt.setString(6, mnum);
		prt.setString(7, ct);
		int i=prt.executeUpdate();
		PreparedStatement srt=con.prepareStatement(cc);
		srt.setString(1, uname);
		srt.setString(2,mnum);
		int j=srt.executeUpdate();
		if(i>0 && j>0) {
			log.info("Registration is Successfull....");
			doctorcontroller.doctor();
			}
		else {
			log.info("Record already exist in system....");
			doctorcontroller.doctor();
		}
		
		}
		catch(Exception e) {
			log.info(MR);
			log.info(e);
			log.info("Mobile number is already present...");
			log.info("Register Again!!!");
			log.info(MR);
		}}
		else {
			log.info("***Error***Enter details as per required...");
			doctorRegistration();
		}
		
	

				
		
		
	}

	public static boolean isvalid(String po) {
		Pattern p=Pattern.compile("^[7-9]\\d{9}$");
		Matcher m=p.matcher(po);
		return m.matches();
	}
	public static boolean agevalid(int op) {

			return (op>=20 ||op<45);
		}
	public static boolean passvalid(String pass) {
		Pattern p=Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@%#$]).{8,12})");
		Matcher m=p.matcher(pass);
		return m.matches();
	}
	public static boolean genderv(String v) {
		return (v.equals("M") || v.equals("F") || v.equals("m") || v.equals("f") || v.equals("male") || v.equals("female") || v.equals("Male") || v.equals("Female"));
	}


	@Override
	public void home() {

		try {
			AppointmentMain.main(null);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	
		
	}

}
package com.virtusa.doctorappointmentproject.model;

public class Patient {
	private String patientName;
	private String patientAge;
	private String patientGender;
	private String patientMobile;
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientAge() {
		return patientAge;
	}
	public void setPatientAge(String patientAge) {
		this.patientAge = patientAge;
	}
	public String getPatientGender() {
		return patientGender;
	}
	public void setPatientGender(String patientGender) {
		this.patientGender = patientGender;
	}
	public String getPatientMobile() {
		return patientMobile;
	}
	public void setPatientMobile(String patientMobile) {
		this.patientMobile = patientMobile;
	}
	public Patient(String patientName, String patientAge, String patientGender, String patientMobile) {
		super();
		this.patientName = patientName;
		this.patientAge = patientAge;
		this.patientGender = patientGender;
		this.patientMobile = patientMobile;
	}
	public Patient() {
		super();
		
	}
	@Override
	public String toString() {
		return "Patient [patientName=" + patientName + ", patientAge=" + patientAge + ", patientGender=" + patientGender
				+ ", patientMobile=" + patientMobile + "]";
	}
	
	

}
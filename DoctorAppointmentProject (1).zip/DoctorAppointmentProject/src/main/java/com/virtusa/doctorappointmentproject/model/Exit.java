package com.virtusa.doctorappointmentproject.model;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



public class Exit {
	static Logger log=LogManager.getLogger(Exit.class.getName());

	public void exit() {
		log.info("---------------------------------------------------------------------");
		log.info("\t\t | Thankyou  for using Doctor Appointment Booking App|");
		log.info("----------------------------------------------------------------------\n\n");
	}
}
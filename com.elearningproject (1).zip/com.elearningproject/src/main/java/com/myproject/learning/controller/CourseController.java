package com.myproject.learning.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.myproject.learning.model.Course;
import com.myproject.learning.model.CourseDto;
import com.myproject.learning.service.CourseService;
@RestController

public class CourseController {
	 
	 private CourseService service; 
	 public CourseController(CourseService service) {
		    super();
		    this.service = service;
		  }
	  @PostMapping("/course")
	  public ResponseEntity<Course> saveProduct(@RequestBody CourseDto c){
		  Course co=new Course(c.getId(),c.getCoursename(),c.getCoursefee(),c.getDname());
		  
	    return new ResponseEntity<>(service.saveCourse(co),HttpStatus.CREATED);
	  }
	
	  @GetMapping("/course")
	  public List<Course> getAllCourses(){
	    return service.getAllCourses();
	  }
	  
	  @GetMapping("/course/{id}")
	  public ResponseEntity<Course> getCourseById(@PathVariable("id") int courseId) {
	    return new ResponseEntity<>(service.findCourseById(courseId),HttpStatus.OK);
	  }
	  
	  
	  @PutMapping("/course/{id}")
	  public ResponseEntity<Course> updateCourse(@RequestBody CourseDto c,@PathVariable("id") int courseId) {
		  Course co=new Course(c.getId(),c.getCoursename(),c.getCoursefee(),c.getDname());

	    return new ResponseEntity<>(service.updateCourse(co, courseId), HttpStatus.OK);
	    
	  }
	  
	  @DeleteMapping("/course/{id}")
	  public ResponseEntity<String> deleteCourse(@PathVariable("id") int courseId){
	    service.deleteCourse(courseId);
	    return new ResponseEntity<>("Deleted",HttpStatus.OK);
	  }
	}




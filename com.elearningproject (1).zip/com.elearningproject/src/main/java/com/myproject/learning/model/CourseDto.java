package com.myproject.learning.model;

public class CourseDto {

private int id;
	
	private String coursename;
	private int coursefee;
	private String dname;
	public CourseDto() {
		super();
	}
	public CourseDto(int id, String coursename, int coursefee, String dname) {
		super();
		this.id = id;
		this.coursename = coursename;
		this.coursefee = coursefee;
		this.dname = dname;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public int getCoursefee() {
		return coursefee;
	}
	public void setCoursefee(int coursefee) {
		this.coursefee = coursefee;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	@Override
	public String toString() {
		return "Course [id=" + id + ", coursename=" + coursename + ", coursefee=" + coursefee + ", dname=" + dname
				+ "]";
	}
	

}


package com.myproject.learning.advice;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ExceutionTimeAdvice {
	org.slf4j.Logger logger=LoggerFactory.getLogger(ExceutionTimeAdvice.class);
	
	@Around("@annotation(com.myproject.learning.advice.TrackExecutionTime)")
	public Object trackTime(ProceedingJoinPoint pj) throws Throwable {
		long st=System.currentTimeMillis();
		Object ob=pj.proceed();
		long en=System.currentTimeMillis();
		Long a=en-st;
		logger.info("Method name");
		logger.info(null, pj.getSignature());
		logger.info("Time Taken to Exceute");	
		logger.info(null,a);
     	return ob;
		
		
	}

}


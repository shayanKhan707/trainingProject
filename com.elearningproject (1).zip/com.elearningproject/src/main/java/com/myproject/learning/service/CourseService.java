package com.myproject.learning.service;

import java.util.List;

import com.myproject.learning.model.Course;

public interface CourseService {

	  public Course saveCourse(Course c);
	  
	  public List<Course> getAllCourses();
	  
	  public Course findCourseById(int id);
	  
	  public Course updateCourse(Course c,int id) ;
	  
	  public void deleteCourse(int id);
	
	

}


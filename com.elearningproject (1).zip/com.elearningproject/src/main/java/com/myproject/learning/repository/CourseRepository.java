package com.myproject.learning.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.myproject.learning.model.Course;

public interface CourseRepository extends JpaRepository<Course,Integer>{

}


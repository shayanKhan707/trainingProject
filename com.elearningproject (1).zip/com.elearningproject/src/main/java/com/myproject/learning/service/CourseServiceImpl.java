package com.myproject.learning.service;

import java.util.List;
import java.util.Optional;

import com.myproject.learning.advice.TrackExecutionTime;
import com.myproject.learning.model.Course;
import com.myproject.learning.repository.CourseRepository;

import org.springframework.stereotype.Service;
@Service
public class CourseServiceImpl implements CourseService{
	  private CourseRepository courserepo;
	  
	  
	  public CourseServiceImpl(CourseRepository courserepo) {
	    super();
	    this. courserepo =  courserepo;
	  }
	@Override
	public Course saveCourse(Course c) {
		return courserepo.save(c);
	}

	@Override
	@TrackExecutionTime
	public List<Course> getAllCourses() {
		return courserepo.findAll();
	}

	@Override
	public Course findCourseById(int id) {
		Optional<Course> co=courserepo.findById(id);
		Course a=null;
		if(co.isPresent()) {
			a=co.get();
		}
		return a;
	}

	@Override
	public Course updateCourse(Course c, int id) {
		Optional<Course> co=courserepo.findById(id);
		Course a=null;
		if(co.isPresent()) {
			a=co.get();
			if(a.getId()!=0) {
				a.setCoursename(c.getCoursename());
				a.setCoursefee(c.getCoursefee());
				a.setDname(c.getDname());
			    }
			    
			courserepo.save(a);
			    
		}
		 return a;
		}
	
	


	@Override
	public void deleteCourse(int id) {
		courserepo.deleteById(id);
		
	}

}


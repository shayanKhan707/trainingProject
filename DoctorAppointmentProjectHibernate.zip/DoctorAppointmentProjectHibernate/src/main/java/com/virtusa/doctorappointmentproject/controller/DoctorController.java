package com.virtusa.doctorappointmentproject.controller;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.virtusa.doctorappointmentproject.main.App;
import com.virtusa.doctorappointmentproject.model.Doctor;
import com.virtusa.doctorappointmentproject.serviceimpl.DoctorServiceImplementation;

public class DoctorController {

	DoctorServiceImplementation doctorserviceimplementation = new DoctorServiceImplementation();
	protected boolean fl = true;

	static Logger log = LogManager.getLogger(DoctorController.class.getName());

	public void doctor() throws Exception {
		try (Scanner sc = new Scanner(System.in)) {
			int choice = 0;

			boolean flag = true;
			while (flag) {

				log.info("\t\t  _________________________");
				log.info("\t\t |                         |");
				log.info("\t\t | Welcome to Doctor Page! |");
				log.info("\t\t |_________________________|");

				log.info("1.Registration \t 2. Login \t 3.Home Page");
				choice = sc.nextInt();

				switch (choice) {
				case 1:
					log.info("\t ----------------------------------");
					log.info("\t\t| This is doctor registration Page |");
					log.info("\t\t ----------------------------------");
					log.info("\n");

					log.info("Please enter your name");
					String uname = new Scanner(System.in).nextLine();
					log.info("Enter qualification");
					String uq = new Scanner(System.in).nextLine();
					log.info("Enter gender(M/F)");
					String p = new Scanner(System.in).nextLine();
					log.info("Enter Mobile number (**10 digits**)");
					String mnum = new Scanner(System.in).nextLine();
					log.info("Enter age (**more than 20**)");
					int agg = new Scanner(System.in).nextInt();
					log.info("Enter Area and City: ");
					String ct = new Scanner(System.in).nextLine();
					log.info(
							"Set password (8-12 characters ,at least(one small,capital,digit,specialcharacter[#$%@]))");
					String pas = new Scanner(System.in).nextLine();
					Doctor d = new Doctor(uname, uq, p, agg, mnum, ct, pas);

					doctorserviceimplementation.doctorRegistration(d);
					doctor();
					flag = false;

					break;
				case 2:
					String mobileNumber;
					new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
					log.info("\t--------------------------------");
					log.info("\t\t| This is doctor login page     |");
					log.info("\t\t---------------------------------");
					log.info("\t\tEnter your Username(mobilenumber)");
					mobileNumber=sc.next();
					log.info("\t\tEnter your Password");
					String password=sc.next();
					doctorserviceimplementation.doctorLogin(mobileNumber, password);
					
					
					break;
				case 3:
					App.main(null);
					break;

				default:
					log.info("Entered Wrong choice..");

				}
			}
		}

	}
}
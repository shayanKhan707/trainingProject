package com.virtusa.doctorappointmentproject.service;

import com.virtusa.doctorappointmentproject.model.Admin;

public interface AdminService {
	public void register(Admin a);
	public Admin login(String u,String pass);
	public void doctorList();
	public void registeredPatientList();
	public void patientAppointmentList();

}
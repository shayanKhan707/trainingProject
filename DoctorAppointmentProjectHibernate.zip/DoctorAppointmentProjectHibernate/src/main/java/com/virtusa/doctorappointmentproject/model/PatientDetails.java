package com.virtusa.doctorappointmentproject.model;

public class PatientDetails {
private String	patientMobileNumber;
private String patientName;
private int patientAge;
private String patientGender;
private String patientPassword;
private String patientConfirmPassword;
public PatientDetails() {
	super();
}
public PatientDetails(String patientMobileNumber, String patientName, int patientAge, String patientGender,
		String patientPassword, String patientConfirmPassword) {
	super();
	this.patientMobileNumber = patientMobileNumber;
	this.patientName = patientName;
	this.patientAge = patientAge;
	this.patientGender = patientGender;
	this.patientPassword = patientPassword;
	this.patientConfirmPassword = patientConfirmPassword;
}
public String getPatientMobileNumber() {
	return patientMobileNumber;
}
public void setPatientMobileNumber(String patientMobileNumber) {
	this.patientMobileNumber = patientMobileNumber;
}
public String getPatientName() {
	return patientName;
}
public void setPatientName(String patientName) {
	this.patientName = patientName;
}
public int getPatientAge() {
	return patientAge;
}
public void setPatientAge(int patientAge) {
	this.patientAge = patientAge;
}
public String getPatientGender() {
	return patientGender;
}
public void setPatientGender(String patientGender) {
	this.patientGender = patientGender;
}
public String getPatientPassword() {
	return patientPassword;
}
public void setPatientPassword(String patientPassword) {
	this.patientPassword = patientPassword;
}
public String getPatientConfirmPassword() {
	return patientConfirmPassword;
}
public void setPatientConfirmPassword(String patientConfirmPassword) {
	this.patientConfirmPassword = patientConfirmPassword;
}
@Override
public String toString() {
	return "PatientDetails [patientMobileNumber=" + patientMobileNumber + ", patientName=" + patientName
			+ ", patientAge=" + patientAge + ", patientGender=" + patientGender + ", patientPassword=" + patientPassword
			+ ", patientConfirmPassword=" + patientConfirmPassword + "]";
}

}


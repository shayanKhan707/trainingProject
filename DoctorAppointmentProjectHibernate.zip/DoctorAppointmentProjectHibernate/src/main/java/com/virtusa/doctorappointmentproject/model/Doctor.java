package com.virtusa.doctorappointmentproject.model;

import java.util.Set;

public class Doctor {
	private String doctorName;
	private String doctorQualification;
	private String doctorGender;
	private int  doctorAge;
	private String doctorMobile;
	private String doctorCity;
	private String doctorPassword;
	private Set<Doctorslot> doctorslot;
	public Set<Doctorslot> getDoctorslot() {
		return doctorslot;
	}

	public void setDoctorslot(Set<Doctorslot> doctorslot) {
		this.doctorslot = doctorslot;
	}

	public Doctor() {
		super();
		
	}
	
	public Doctor(String doctorName, String doctorQualification, String doctorGender, int doctorAge,
			String doctorMobile, String doctorCity, String doctorPassword) {
		super();
		this.doctorName = doctorName;
		this.doctorQualification = doctorQualification;
		this.doctorGender = doctorGender;
		this.doctorAge = doctorAge;
		this.doctorMobile = doctorMobile;
		this.doctorCity = doctorCity;
		this.doctorPassword = doctorPassword;
	}
	
	

	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDoctorQualification() {
		return doctorQualification;
	}
	public void setDoctorQualification(String doctorQualification) {
		this.doctorQualification = doctorQualification;
	}
	public String getDoctorGender() {
		return doctorGender;
	}
	public void setDoctorGender(String doctorGender) {
		this.doctorGender = doctorGender;
	}
	public int getDoctorAge() {
		return doctorAge;
	}
	public void setDoctorAge(int doctorAge) {
		this.doctorAge = doctorAge;
	}
	public String getDoctorMobile() {
		return doctorMobile;
	}
	public void setDoctorMobile(String doctorMobile) {
		this.doctorMobile = doctorMobile;
	}
	public String getDoctorCity() {
		return doctorCity;
	}
	public void setDoctorCity(String doctorCity) {
		this.doctorCity = doctorCity;
	}
	public String getDoctorPassword() {
		return doctorPassword;
	}
	public void setDoctorPassword(String doctorPassword) {
		this.doctorPassword = doctorPassword;
	}
	@Override
	public String toString() {
		return "doctorName=" + doctorName + ", doctorQualification="
				+ doctorQualification + ", doctorGender=" + doctorGender + ", doctorAge=" + doctorAge
				+ ", doctorMobile=" + doctorMobile + ", doctorCity=" + doctorCity + ", doctorPassword=" + doctorPassword
				+ "]";
	}
	
	
	
	

}

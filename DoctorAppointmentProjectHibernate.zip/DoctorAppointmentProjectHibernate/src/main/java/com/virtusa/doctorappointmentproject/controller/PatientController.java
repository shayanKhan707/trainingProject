package com.virtusa.doctorappointmentproject.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.virtusa.doctorappointmentproject.main.App;
import com.virtusa.doctorappointmentproject.model.PatientDetails;
import com.virtusa.doctorappointmentproject.serviceimpl.AdminServiceImplementation;
import com.virtusa.doctorappointmentproject.serviceimpl.PatientServiceImplementation;


public class PatientController {

	static Logger log=LogManager.getLogger(PatientController.class.getName());
	PatientServiceImplementation patientserviceimplementation=new PatientServiceImplementation();

	private static final String MS="\t\t _________________________";
	
	
	
	@SuppressWarnings("resource")
	public void patient() throws Exception {
		
		boolean flag=true;
		while(flag)
		{
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			
			log.info(MS);
			log.info("\t\t | Welcome to Patient Page!|");
			log.info(MS);
			log.info(" ");
			log.info("1.Registration  \t 2.Login \t 3.Home Page\n");
			int ch=new Scanner(System.in).nextInt();
			switch(ch)
			{
				case 1:		
					log.info("\n");
					log.info(MS);
					log.info("\t\t  Welcome to Patient Registration Page !");
					log.info(MS);
					log.info("\n");
					log.info("Please enter your name");
					String mop=new Scanner(System.in).nextLine();
					log.info("enter your age: ");
					int age=new Scanner(System.in).nextInt();
					log.info("Please enter your gender(M/F) :");
					String gd=new Scanner(System.in).nextLine();
					log.info("Please enter your Mobile number (**10 digits**)");
					String mobilenu=new Scanner(System.in).nextLine();
					
					boolean k=false;
					if(k!=false) {
						log.info("Patient already registered ");
					}
					else {
						log.info("Set password (8-12 characters ,at least(one small,capital,digit,specialcharacter[#$%@])) ");
						String pass=new Scanner(System.in).nextLine();
						log.info("Confirm password : ");
						String pass1=new Scanner(System.in).nextLine();
						PatientDetails pd=new PatientDetails(mobilenu,mop,age,gd,pass,pass1);
						if(pass.equals(pass1)) {
							patientserviceimplementation.patientRegistration(pd);
						}
						else {
							log.info("Password mismatch !!");
						}
						try {
							App.main(null);
						} catch (Exception e) {
							
							e.printStackTrace();
						}
						
						
				
					
					}
					break;
				case 2:
					log.info("Please enter your Mobile number (**10 digits**)");
					String mobilenum=new Scanner(System.in).nextLine();
					log.info("Set password (8-12 characters ,at least(one small,capital,digit,specialcharacter[#$%@])) ");
					String pass=new Scanner(System.in).nextLine();
					
					patientserviceimplementation.patientLogin(mobilenum,pass);
					flag=false;
					break;
				case 3:
					App.main(null);
					break;
				

				default:
					log.info("\nYou entered wrong choice. enter your choice again....!!!");
				
					Thread.sleep(1000);
					break;
			}
		}

	}}
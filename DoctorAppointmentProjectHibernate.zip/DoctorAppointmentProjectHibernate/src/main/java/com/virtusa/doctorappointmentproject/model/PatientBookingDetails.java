package com.virtusa.doctorappointmentproject.model;

public class PatientBookingDetails {
	
	private String patientNameBooking;
	private int patientAgeBooking;
	private String patientGenderBooking;
	private String patientMobileNumber;
	private String datee;
	private String dname;
	private String time;
	public PatientBookingDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PatientBookingDetails(String patientNameBooking, int patientAgeBooking, String patientGenderBooking,
			String patientMobileNumber, String datee, String dname, String time) {
		super();
		this.patientNameBooking = patientNameBooking;
		this.patientAgeBooking = patientAgeBooking;
		this.patientGenderBooking = patientGenderBooking;
		this.patientMobileNumber = patientMobileNumber;
		this.datee = datee;
		this.dname = dname;
		this.time = time;
	}
	public String getPatientNameBooking() {
		return patientNameBooking;
	}
	public void setPatientNameBooking(String patientNameBooking) {
		this.patientNameBooking = patientNameBooking;
	}
	public int getPatientAgeBooking() {
		return patientAgeBooking;
	}
	public void setPatientAgeBooking(int patientAgeBooking) {
		this.patientAgeBooking = patientAgeBooking;
	}
	public String getPatientGenderBooking() {
		return patientGenderBooking;
	}
	public void setPatientGenderBooking(String patientGenderBooking) {
		this.patientGenderBooking = patientGenderBooking;
	}
	public String getPatientMobileNumber() {
		return patientMobileNumber;
	}
	public void setPatientMobileNumber(String patientMobileNumber) {
		this.patientMobileNumber = patientMobileNumber;
	}
	public String getDatee() {
		return datee;
	}
	public void setDatee(String datee) {
		this.datee = datee;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "PatientBookingDetails [patientNameBooking=" + patientNameBooking + ", patientAgeBooking="
				+ patientAgeBooking + ", patientGenderBooking=" + patientGenderBooking + ", patientMobileNumber="
				+ patientMobileNumber + ", datee=" + datee + ", dname=" + dname + ", time=" + time + "]";
	}
	
	

}

package com.virtusa.doctorappointmentproject.service;

import java.io.IOException;
import java.sql.SQLException;

import com.virtusa.doctorappointmentproject.model.PatientDetails;

public interface PatientService {
	public void patientRegistration(PatientDetails p);
	public void patientLogin(String mn,String pass) throws InterruptedException, IOException, SQLException;
}

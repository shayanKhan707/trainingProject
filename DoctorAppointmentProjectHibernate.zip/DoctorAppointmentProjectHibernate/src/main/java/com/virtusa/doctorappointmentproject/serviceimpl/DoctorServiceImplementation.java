package com.virtusa.doctorappointmentproject.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.doctorappointmentproject.controller.DoctorController;
import com.virtusa.doctorappointmentproject.main.App;
import com.virtusa.doctorappointmentproject.model.Doctor;
import com.virtusa.doctorappointmentproject.model.Doctorslot;
import com.virtusa.doctorappointmentproject.model.PatientBookingDetails;
import com.virtusa.doctorappointmentproject.service.DoctorService;
import com.virtusa.doctorappointmentproject.util.HibernateUtil;

public class DoctorServiceImplementation implements DoctorService {
	static Logger log = LogManager.getLogger(DoctorServiceImplementation.class.getName());
	private SessionFactory factory = HibernateUtil.getSessionFactory();
	String r;
	String pro;
	AdminServiceImplementation adminserviceimplementation=new AdminServiceImplementation();

	@Override
	public void doctorLogin(String doctorMob, String doctorPass) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		try (Scanner sc = new Scanner(System.in)) {
			byte choice = 0;
			boolean flag = false;
			String flag11 = "false";

			Doctor doc = session
					.createQuery(
							"from Doctor d where d.doctorMobile=:doctorMobile and d.doctorPassword=:doctorPassword",
							Doctor.class)
					.setParameter("doctorMobile", doctorMob).setParameter("doctorPassword", doctorPass).uniqueResult();
			if (doc != null) {

				flag = true;
				flag11 = "true";
				r = doc.getDoctorName();
				pro = doctorMob;
			}
			while (flag) {

				log.info("\t----------------------------------");
				log.info("\t\t| Welcome Doctor  {}  |", doc.getDoctorName());
				log.info("\t\t----------------------------------");
				log.info("Press 1 to see your Appointments. ");
				log.info("Press 2 to enter your Availability time. ");
				log.info("Press 3 to go back to Home page. ");
				choice = sc.nextByte();

				switch (choice) {
				case 1:
					detailsPatient(r);
					break;

				case 2:
					slotavailability();
					break;
				case 3:

					App.main(null);

					break;

				default:
					log.info("Invalid choice :)");
					System.exit(0);

				}

			}
			if (flag11.equals("false")) {
				log.info("Invalid Credentials !!");
				Thread.sleep(900);

				App.main(null);
			}
		} catch (Exception e) {
			Thread.currentThread().interrupt();
		}

		session.getTransaction().commit();

		session.close();

	}

	@Override
	public void doctorRegistration(Doctor d) {

		Doctorslot ds = new Doctorslot( d.getDoctorName(),d);
		Transaction transaction = null;
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			session.save(d);
			session.save(ds);
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
		}

	}

	@Override
	public void home() {
	
		try {
			App.main(null);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	@SuppressWarnings("deprecation")
	private void slotavailability() throws Exception {
		DoctorController doctorcontroller = new DoctorController();
		Scanner sc = new Scanner(System.in);
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		log.info("\t----------------------------------");
		log.info("\t\t| Hello Doctor   {}  |", r);
		log.info("\t\t----------------------------------");

		log.info("Enter the respective date(dd-mm-yyyy) :");
		String datee = sc.nextLine();
		log.info("Enter Slot-1(hh:mm pm/am):");
		String tme1 = sc.nextLine();
		log.info("Enter Slot-2(hh:mm pm/am):");
		String tme2 = sc.nextLine();
		log.info("Enter Slot-3(hh:mm pm/am) :");
		String tme3 = sc.nextLine();
		log.info("Enter Slot-4(hh:mm pm/am):");
		String tme4 = sc.nextLine();
		log.info("Enter Slot-5(hh:mm pm/am):");
		String tme5 = sc.nextLine();
		log.info(datee);
		String ryt = "update Doctorslot set date1=:date1,slot1=:slot1,slot2=:slot2,slot3=:slot3,slot4=:slot4,slot5=:slot5"
				+ " where doctorMobile=:doctorMobile";
		Query query = session.createQuery(ryt);
		query.setParameter("date1", datee);
		query.setParameter("slot1", tme1);
		query.setParameter("slot2", tme2);
		query.setParameter("slot3", tme3);
		query.setParameter("slot4", tme4);
		query.setParameter("slot5", tme5);
		query.setParameter("doctorMobile", pro);
		int result = query.executeUpdate();
		if (result > 0) {
			log.info("Records has been updated Successfully..");
			App.main(null);
		} else {
			log.info("Invalid data..");
			doctorcontroller.doctor();

		}

	}
	public void detailsPatient(String dname) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		String hql = "FROM PatientBookingDetails where dname=:dname";
	    Query query = session.createQuery(hql);
	    query.setParameter("dname", dname);
		List<PatientBookingDetails> pbr = query.list();
	
		if (pbr!=null) {

		for(PatientBookingDetails pbd:pbr) {
		log.info("Patient Name\t\t"+"Patient Age\t\t"+"Patient Gender\t\t"+"Patient Mobile\t\t"+"Appointment Date\t\t"+"Time");
		
		
			log.info("{} \t\t {} \t\t\t {} \t\t\t {} \t\t {} \t\t\t {}",pbd.getPatientNameBooking(),pbd.getPatientAgeBooking(),pbd.getPatientGenderBooking(),pbd.getPatientMobileNumber(),pbd.getDatee(),pbd.getTime());
			
		}
		}
	}

}
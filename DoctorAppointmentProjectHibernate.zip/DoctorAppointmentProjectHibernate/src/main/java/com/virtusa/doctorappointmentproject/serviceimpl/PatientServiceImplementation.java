package com.virtusa.doctorappointmentproject.serviceimpl;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.doctorappointmentproject.main.App;
import com.virtusa.doctorappointmentproject.model.Doctor;
import com.virtusa.doctorappointmentproject.model.Doctorslot;
import com.virtusa.doctorappointmentproject.model.PatientBookingDetails;
import com.virtusa.doctorappointmentproject.model.PatientDetails;
import com.virtusa.doctorappointmentproject.service.PatientService;
import com.virtusa.doctorappointmentproject.util.HibernateUtil;



public class PatientServiceImplementation implements PatientService {
	static Logger log = LogManager.getLogger(PatientServiceImplementation.class.getName());
	private static final String MS="\t\t _________________________";
	private SessionFactory factory = HibernateUtil.getSessionFactory();
	private String dmbile;
	private String docname;
	private String slotss;
	
@Override
public void patientRegistration(PatientDetails p)  {

			if(isvalid(p.getPatientMobileNumber()) && passvalid(p.getPatientPassword()) && genderv(p.getPatientGender())) {
			
				Transaction transaction = null;
				try (Session session = factory.openSession()) {
					transaction = session.beginTransaction();
					session.save(p);
					
					transaction.commit();
				} catch (Exception e) {
					if (transaction != null) {
						transaction.rollback();
}
					log.info("Registration Successful");
				}	}

else {
				
					log.info("Invalid");
				}
				
			
			
			
}
	public void openSlot(String dm) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		String hql = "FROM Doctorslot where doctorMobile=:doctorMobile";
	    Query query = session.createQuery(hql);
	    query.setParameter("doctorMobile",dm);
		Doctorslot dsa = (Doctorslot) query.uniqueResult();
		
		log.info(" Availability Date \t\t"+"Slot1\t\t"+"Slot2\t\t"+"Slot3\t\t"+"Slot4\t\t"+"Slot5\t\t");
		
			if(dsa!=null) {
			log.info("{} \t\t\t {} \t {} \t {}\t {}\t {}",dsa.getDate1(),dsa.getSlot1(),dsa.getSlot2(),dsa.getSlot3(),dsa.getSlot4(),dsa.getSlot5());
		
			}
		
		
		
	
		
	}
public void patientBookingDetails(PatientBookingDetails pd)  {

	//if(isvalid(mobilenu) && passvalid(pass) && genderv(gd)) {
	
		Transaction transaction = null;
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			session.save(pd);
			
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
}
		
		
			
		
		
	}
		log.info("done");
	
}
private void deleteslots(String slot,String dm) throws SQLException{
	
	Session session = HibernateUtil.getSessionFactory().openSession();
	session.beginTransaction();
		 String dlt="Update Doctorslot SET "+slot+"=:"+slot+" where doctorMobile=:doctorMobile";
		 Query query = session.createQuery(dlt);
		 String k="Booked";
			query.setParameter(""+slot+"", k);
			query.setParameter("doctorMobile", dm);
		         
			int result = query.executeUpdate();
			if (result > 0) {
				log.info("success");
				
			} 
}

public void showDetails() {
	log.info("Enter Doctor type : ");
	String no=new Scanner(System.in).nextLine();
	if(!(no.equals("Orthopedecian")|| no.equals("Cardiologist")|| no.equals("mbbs")||no.equals("Gynecologist"))) {
		log.info("Invalid doctor type");
		showDetails();
	}
	else {
	
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		String hql = "FROM Doctor";
	    Query query = session.createQuery(hql);
		List<Doctor> dr = query.list();
		transaction.commit();


	
	
	
	log.info("Doctor Name\t\t"+"Doctor Qualification\t\t"+"Doctor Gender\t\t"+"Doctor Age\t\t"+"Doctor Mobile no.\t\t"+"Doctor City\t\t");
	if(dr!=null) {
		for(Doctor da:dr) {
		
			log.info("{} \t\t {} \t\t {} \t\t {} \t\t {} \t\t {}",da.getDoctorName(),da.getDoctorQualification(),da.getDoctorGender(),da.getDoctorAge(),da.getDoctorMobile(),da.getDoctorCity());
			
			
	}
	

}
	}
}
		
@Override
public void patientLogin(String mn, String pass) throws InterruptedException, IOException, SQLException {
	// TODO Auto-generated method stub
	Session session = HibernateUtil.getSessionFactory().openSession();
	session.beginTransaction();
	Scanner sc=new Scanner(System.in);
	String mobileNumber;
	
	
	boolean flag1=false;
	
		PatientDetails p = session
				.createQuery(
						"from PatientDetails p where p.patientMobileNumber=:patientMobileNumber and p.patientPassword=:patientPassword",
						PatientDetails.class)
				.setParameter("patientMobileNumber", mn).setParameter("patientPassword", pass).uniqueResult();
	
	if(p!=null) {
		flag1=true;	
	}else {
		log.info("no patient found");
	}
	if(flag1)
	{		
		Thread.sleep(1000);
		new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			log.info("\t\t  _________________________");
			log.info("\t\t |                         |");
			log.info("\t\t |     Book Appointment    |");
			log.info("\t\t |_________________________|");
			log.info(" Welcome  {} , to book appointment, choose your doctor..",p.getPatientName());
		
			Thread.sleep(1000);

			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			log.info("\t\t  _________________________");
			log.info("\t\t |                         |");
			log.info("\t\t |     Book Appointment    |");
			log.info("\t\t |_________________________|");
		
		    showDetails();
			log.info("Enter doctor mobile no. to book appointment : ");
			String domobile=new Scanner(System.in).nextLine();
			dmbile=domobile;
			openSlot(domobile);
			Thread.sleep(3000);
			log.info("Enter Date");
			String dte=new Scanner(System.in).nextLine();
			log.info("Enter Slot :");
			String slot=new Scanner(System.in).nextLine();
			slotss=slot;

			Doctorslot ds = session
					.createQuery(
							" from Doctorslot  where doctorMobile=:doctorMobile and date1=:date1",
							Doctorslot.class)
					.setParameter("doctorMobile", domobile).setParameter("date1", dte).uniqueResult();
			if(ds!=null) {
				
				log.info("Enter Your name :");
				String una=new Scanner(System.in).nextLine();
				log.info("Enter Your age :");
				int uage=new Scanner(System.in).nextInt();
				String agee=String.valueOf(uage);
				log.info("Enter  Your gender(M/F) :");
				String gn=new Scanner(System.in).nextLine();
				PatientBookingDetails pbd=new PatientBookingDetails(una,uage,gn,mn,dte,ds.getD_name(),slot);
				patientBookingDetails(pbd);
				deleteslots(slot,domobile);
				
				
			
			
	}
			
		
	
}

	

}
public static boolean isvalid(String po) {
	Pattern p=Pattern.compile("^[7-9]\\d{9}$");
	Matcher m=p.matcher(po);
	return m.matches();
}
public static boolean setime(String opl) {
	return !(opl.equals("BOOKED"));
}
public static boolean passvalid(String pass) {
	Pattern p=Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@%#$]).{8,12})");
	Matcher m=p.matcher(pass);
	return m.matches();
}
public static boolean genderv(String v) {
	return (v.equals("M") || v.equals("F") || v.equals("f") || v.equals("m"));
}
public static boolean slottime(String slot) {
	return slot.length()==7||slot.length()==8;
}
public static boolean checkage(int agecheck) {
	
		return  agecheck<=80;
	
}
}
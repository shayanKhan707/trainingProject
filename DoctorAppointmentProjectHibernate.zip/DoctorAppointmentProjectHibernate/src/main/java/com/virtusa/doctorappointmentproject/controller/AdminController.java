package com.virtusa.doctorappointmentproject.controller;


import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.virtusa.doctorappointmentproject.main.App;
import com.virtusa.doctorappointmentproject.model.Admin;

import com.virtusa.doctorappointmentproject.serviceimpl.AdminServiceImplementation;


public class AdminController {
	static boolean flag=false;
	
	
	private static final String MR="--------------------------------------------------------------------";
	static Logger log=LogManager.getLogger(AdminController.class.getName());
	AdminServiceImplementation adminserviceimplementation=new AdminServiceImplementation();
	
	@SuppressWarnings("resource")
	public void admin() throws Exception {
		Scanner sc = new Scanner(System.in);
			byte choice;
			
			log.info(MR);
			log.info(MR);
			log.info("Admin Dashboard");
			log.info("1.Register  2.Login\n");

			int ch=sc.nextInt();
			switch(ch) 
			{
			
			case 1:
				log.info("Enter admin name : ");
				String name=new Scanner(System.in).nextLine();
			log.info("Enter admin username : ");
			String uns=new Scanner(System.in).nextLine();
			log.info("Enter admin password : ");
			String pns=new Scanner(System.in).nextLine();
			log.info(MR);
			log.info(MR);
			Admin a=new Admin(name,uns,pns);
			adminserviceimplementation.register(a);
			admin();
			break;
			case 2:log.info("Enter admin username : ");
			String unsa=new Scanner(System.in).nextLine();
			log.info("Enter admin password : ");
			String pnsa=new Scanner(System.in).nextLine();
			Admin ad=adminserviceimplementation.login(unsa, pnsa);
			
			if(ad!=null) {
			

			while(!flag)
			{
				new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
				log.info("\t\t  ____________________________");
				log.info("\t\t |----------------------------|");
				log.info("\t\t |*****Welcome {}****|",ad.getUserName());
				log.info("\t\t |____________________________|\n\n");
				log.info("1. Doctor list \t2. Registered Patients list \t3.Pateints with Appointment list \t 4.Delete the doctor Record\t 5.Home Page  \n\nEnter Your Choice.");
				choice=sc.nextByte();
			
				switch(choice)
				{
				case 1:
					  adminserviceimplementation.doctorList();
					
					break;
				case  2:
					adminserviceimplementation.registeredPatientList();
			
					break;
				case 3:
					adminserviceimplementation.patientAppointmentList();

					break;
				case 4:
					adminserviceimplementation.doctordelete();
					break;
				case 5:
					App.main(null);
					break;
					default:
						log.info("Invalid Choice...Something Went Wrong !!!");		
						break;
}
}
			
			}
			else {
				log.info("Invalid Login Credentials...");
				admin();
			}
			default:
				log.info("wrong choice");
		}
}
}
package com.virtusa.doctorappointmentproject.serviceimpl;

import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.virtusa.doctorappointmentproject.main.App;
import com.virtusa.doctorappointmentproject.model.Admin;
import com.virtusa.doctorappointmentproject.model.Doctor;
import com.virtusa.doctorappointmentproject.model.PatientBookingDetails;
import com.virtusa.doctorappointmentproject.model.PatientDetails;
import com.virtusa.doctorappointmentproject.service.AdminService;
import com.virtusa.doctorappointmentproject.util.HibernateUtil;

public class AdminServiceImplementation implements AdminService {
	static Logger log = LogManager.getLogger(AdminServiceImplementation.class.getName());

	private SessionFactory factory = HibernateUtil.getSessionFactory();

	@Override
	public void register(Admin a) {
		Transaction transaction = null;
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			session.save(a);
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
		}
		
		

	}
		
	

	@Override
	public Admin login(String u, String pass) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Admin ad=null;
		 ad = session
				.createQuery(
						"from Admin a where a.userName=:userName and a.password=:password",
						Admin.class)
				.setParameter("userName", u).setParameter("password", pass).uniqueResult();
	
		
		return ad;
	}



	@SuppressWarnings("unchecked")
	@Override
	public void doctorList() {
		Session session =factory.openSession();
		Transaction transaction = session.beginTransaction();
		String hql = "FROM Doctor";
	    @SuppressWarnings("rawtypes")
		Query query = session.createQuery(hql);
		List<Doctor> dr = query.list();
		transaction.commit();


	
	
	
	log.info("Doctor Name\t\t"+"Doctor Qualification\t\t"+"Doctor Gender\t\t"+"Doctor Age\t\t"+"Doctor Mobile no.\t\t"+"Doctor City\t\t");
	if(dr!=null) {
		for(Doctor da:dr) {
		
			log.info("{} \t\t {} \t\t {} \t\t {} \t\t {} \t\t {}",da.getDoctorName(),da.getDoctorQualification(),da.getDoctorGender(),da.getDoctorAge(),da.getDoctorMobile(),da.getDoctorCity());
			
			
	}
	

}
	}



	@Override
	public void registeredPatientList() {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		String hql = "FROM PatientDetails";
	    Query query = session.createQuery(hql);
		List<PatientDetails> pr = query.list();
		transaction.commit();
		log.info("Patient Name\t"+"Patient Age\t"+"Patient Gender\t"+"Patient Mobile no.\t");

	    if(pr!=null) {
	    	for(PatientDetails pa:pr) {
			log.info("{} \t\t\t\t {} \t\t\t  {} \t\t  {} \t\t\t {} \t\t {} \t\t\t{}",pa.getPatientName(),pa.getPatientAge(),pa.getPatientGender(),pa.getPatientMobileNumber()) ;
			
			
		}

		
	}
	}



	@Override
	public void patientAppointmentList() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		String hql = "FROM PatientBookingDetails";
	    Query query = session.createQuery(hql);
		List<PatientBookingDetails> pbr = query.list();
		transaction.commit();
	
		log.info("Patient Name Booking\t\t"+"Patient Age\t\t"+"Patient Gender\t\t"+"Patient Mobile no.\t\t"+"Doctor Name\t\t"+"Appointment Date\t\t"+"Time");
		if(pbr!=null) {
			for(PatientBookingDetails pbd:pbr) {
			log.info("{} \t\t\t\t {} \t\t\t  {} \t\t  {} \t\t\t {} \t\t {} \t\t\t{}",pbd.getPatientNameBooking(),pbd.getPatientAgeBooking(),pbd.getPatientGenderBooking(),pbd.getPatientMobileNumber(),pbd.getDname(),pbd.getDatee(),pbd.getTime()) ;
			
			}
		}
		
	}
	public void doctordelete() throws Exception {
		Scanner sc=new Scanner(System.in);
		
		new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		log.info("\t\t----------------------------------------");
		log.info("\t\t----------------------------------------");
		log.info("Press 1 to Delete Doctor record. ");
		log.info("Press 2 to go back to Home page. ");
		byte choice=sc.nextByte();
		switch(choice) {
		case 1:
			deleteit();
			break;
		case 2:
			App.main(null);
			break;
		default:
			System.exit(0);
			
		
		
	}
}



	@SuppressWarnings("resource")
	private void deleteit() {
        log.info("Enter Doctor mobile :");
		
		String dmob=new Scanner(System.in).nextLine();
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
			 String dlt="delete from Doctor where doctorMobile=:doctorMobile";
			 Query query = session.createQuery(dlt);
			
				query.setParameter("doctorMobile", dmob);
			         
				int result = query.executeUpdate();
				String dlt1="delete from Doctorslot where doctorMobile=:doctorMobile";
				 Query query1 = session.createQuery(dlt1);
				
					query1.setParameter("doctorMobile", dmob);
				         
					int result1 = query1.executeUpdate();
				
				if (result > 0 ) {
					log.info("Doctor record deleted");
					
				} 
	}
		
	
	}
	
		
	
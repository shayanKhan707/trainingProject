package com.virtusa.doctorappointmentproject.main;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.virtusa.doctorappointmentproject.controller.AdminController;
import com.virtusa.doctorappointmentproject.controller.DoctorController;
import com.virtusa.doctorappointmentproject.controller.PatientController;

public class App {

	
		static Logger log=LogManager.getLogger(App.class.getName());
		static boolean flag=false;
		public static void main(String[] args) throws Exception {
			DoctorController doctorcontroller=new DoctorController();
			PatientController patientcontroller=new PatientController();
			AdminController admincontroller=new AdminController();
			@SuppressWarnings("resource")
			Scanner sc=new Scanner(System.in);
			if(!flag)
			{
			log.info("---------------------------------------------------------------------");
			log.info("\t\t | Welcome to Doctor AppointmentBooking |");
			log.info("----------------------------------------------------------------------\n\n");
			log.info("1. Doctor \t 2. Patient \t 3. Admin \t 4. Exit");
			int choice=sc.nextInt();
			switch(choice) {
			case 1:
				doctorcontroller.doctor();
				
				break;
				case 2:
				 patientcontroller.patient();								
				break;
				case 3:
				
				admincontroller.admin();
				break;
				case 4:
					exit();
					System.exit(0);
					break;
				default:
				System.exit(0);


			}
			
			
			
			}
			
			
		
			
		}

		public static void exit() {
			log.info("---------------------------------------------------------------------");
			log.info("\t\t | Thankyou  for using Doctor Appointment Booking App|");
			log.info("----------------------------------------------------------------------\n\n");
		}

	    
		
		
		
	
		
	}

		
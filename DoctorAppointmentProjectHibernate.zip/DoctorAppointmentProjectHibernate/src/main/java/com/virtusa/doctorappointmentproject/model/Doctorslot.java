package com.virtusa.doctorappointmentproject.model;

public class Doctorslot {
	private int slotId;
	
	private String dmobile;
	private String dname;
	private String slot1;
	private String slot2;
	private String slot3;
	private String slot4;
	private String slot5;
	private String date1;
	private Doctor doctor;
	public Doctorslot() {
		super();
		
	}
	
	public Doctorslot(String dname, Doctor doctor) {
		super();
		this.dname = dname;
		this.doctor = doctor;
	}

	public Doctorslot(String dmobile, String dname, String slot1, String slot2, String slot3, String slot4,
			String slot5, String date1, Doctor doctor) {
		super();
		this.dmobile = dmobile;
		this.dname = dname;
		this.slot1 = slot1;
		this.slot2 = slot2;
		this.slot3 = slot3;
		this.slot4 = slot4;
		this.slot5 = slot5;
		this.date1 = date1;
		this.doctor = doctor;
	}

	public Doctorslot(String dmobile, String dname) {
		super();
		this.dmobile = dmobile;
		this.dname = dname;
	}
	public int getSlotId() {
		return slotId;
	}

	public void setSlotId(int slotId) {
		this.slotId = slotId;
	}
	public String getD_mobile() {
		return dmobile;
	}
	public void setD_mobile(String dmobile) {
		this.dmobile = dmobile;
	}
	public String getD_name() {
		return dname;
	}
	public void setD_name(String dname) {
		this.dname = dname;
	}
	public String getSlot1() {
		return slot1;
	}
	public void setSlot1(String slot1) {
		this.slot1 = slot1;
	}
	public String getSlot2() {
		return slot2;
	}
	public void setSlot2(String slot2) {
		this.slot2 = slot2;
	}
	public String getSlot3() {
		return slot3;
	}
	public void setSlot3(String slot3) {
		this.slot3 = slot3;
	}
	public String getSlot4() {
		return slot4;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	public void setSlot4(String slot4) {
		this.slot4 = slot4;
	}
	public String getSlot5() {
		return slot5;
	}
	public void setSlot5(String slot5) {
		this.slot5 = slot5;
	}
	public String getDate1() {
		return date1;
	}
	public void setDate1(String date1) {
		this.date1 = date1;
	}
	@Override
	public String toString() {
		return "Doctorslot [dmobile=" + dmobile + ", dname=" + dname + ", slot1=" + slot1 + ", slot2=" + slot2
				+ ", slot3=" + slot3 + ", slot4=" + slot4 + ", slot5=" + slot5 + ", date1=" + date1 + "]";
	}
	
}
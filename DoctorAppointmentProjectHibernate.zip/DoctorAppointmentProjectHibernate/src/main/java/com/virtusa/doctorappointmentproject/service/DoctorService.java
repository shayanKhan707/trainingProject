package com.virtusa.doctorappointmentproject.service;

import java.util.List;

import com.virtusa.doctorappointmentproject.model.Doctor;

public	interface DoctorService {
	 public void doctorLogin(String doctorMobile,String doctorPassword);
	 public void doctorRegistration(Doctor d) throws Exception;
	 public void home();
}

